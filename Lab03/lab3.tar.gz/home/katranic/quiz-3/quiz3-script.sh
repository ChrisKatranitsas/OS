#!/bin/bash

# Set default input file and search file if no arguments are provided
input_file="usernames.txt"
search_file="tarball.tar.gz"

# Override defaults if arguments are provided
if [ -n "$1" ]; then
    input_file="$1"
fi

if [ -n "$2" ]; then
    search_file="$2"
fi

# Verify that the input file exists
if [ ! -f "$input_file" ]; then
    echo "Error: Input file '$input_file' not found."
    exit 1
fi

# Loop through each username in the file
while read -r user; do
    echo "User: $user"
    echo "##########"
    
    # Check if we can access the user's home directory
    if [ ! -d "/home/$user" ]; then
        echo "Permission denied"
        continue
    fi
    
    # Look for the specified file in the user's home directory
    file_path="/home/$user/$search_file"
    
    # Perform file checks
    if [ ! -e "$file_path" ]; then
        echo "File not found"
    elif [ ! -r "$file_path" ]; then
        echo "Permission denied"
    else
        # Get file size in bytes
        file_size=$(stat -c %s "$file_path")
        echo "File found, size $file_size bytes"
    fi
    
    echo "..."
done < "$input_file"
